package com.baseball.pinchhitter.controller;

import com.baseball.pinchhitter.model.vo.*;
import com.baseball.pinchhitter.service.PinchHitterService;
import com.baseball.pinchhitter.view.PinchHitterMenu;
import java.util.ArrayList;
import java.util.List;

public class PinchHitterController {
    private PinchHitterService service = new PinchHitterService();
    private PinchHitterMenu menu = new PinchHitterMenu();

    public void start() {
        while (true) {
            int choice = menu.mainMenu();
            switch (choice) {
                case 1: regBatter(); break;
                case 2: regPitcher(); break;
                case 3: regMatch(); break;
                case 4: findBest(); break;
                case 0: System.out.println("종료합니다."); return;
            }
        }
    }

    private void regBatter() {
        String name = menu.inputKoreanName("타자 이름");
        String hand = menu.inputHand("타석");
        double avg = menu.inputDouble("시즌 타율");
        int hr = menu.inputInt("홈런 개수");
        double rAvg = menu.inputDouble("득점권 타율");
        service.addBatter(new Batter(name, hand, avg*300, hr*2.5, rAvg*300, avg));
        System.out.println("[완료] " + name + " 등록됨.");
    }

    private void regPitcher() {
        String name = menu.inputKoreanName("투수 이름");
        String hand = menu.inputHand("투구손");
        double era = menu.inputDouble("ERA");
        double power = menu.inputDouble("구위 점수(0~100)");
        service.addPitcher(new Pitcher(name, hand, era, power));
        System.out.println("[완료] 투수 등록됨.");
    }

    private void regMatch() {
        String b = menu.inputKoreanName("대상 타자 이름");
        String p = menu.inputKoreanName("대상 투수 이름");
        double mAvg = menu.inputDouble("상대 타율");
        service.addMatchUp(new MatchUp(b, p, mAvg));
        System.out.println("[완료] 매치업 등록됨.");
    }

    private void findBest() {
        if(service.getPitchers().isEmpty() || service.getBatters().isEmpty()) {
            System.out.println("[오류] 타자와 투수를 먼저 등록하세요.");
            return;
        }

        // 1. 선발 라인업 입력 (이 명단에 있는 이름은 제외됨)
        List<String> lineup = new ArrayList<>();
        System.out.println("\n--- [현재 경기 중인 선발 타자 9명 입력] ---");
        for(int i=1; i<=9; i++) {
            lineup.add(menu.inputKoreanName(i + "번 타자"));
        }

        // 2. 투수 선택
        System.out.println("\n--- [상대 투수 선택] ---");
        for(int i=0; i<service.getPitchers().size(); i++) {
            System.out.println(i + ". " + service.getPitchers().get(i).getName());
        }
        int pIdx = menu.inputInt("투수 번호 선택");
        
        // 3. 상황 및 추천
        int base = menu.inputBaseState();
        Batter result = service.recommend(pIdx, base, lineup);
        
        System.out.println("\n============================");
        if (result != null) System.out.println("★ 추천 대타(벤치 멤버): " + result.getName() + "\n★ 상세: " + result.toString());
        else System.out.println("추천 가능한 벤치 멤버가 없습니다.");
        System.out.println("============================");
    }
}