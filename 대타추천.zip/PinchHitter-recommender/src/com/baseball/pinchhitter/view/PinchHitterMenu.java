package com.baseball.pinchhitter.view;

import java.util.Scanner;
import java.util.regex.Pattern;

public class PinchHitterMenu {
    private Scanner sc = new Scanner(System.in);

    public int mainMenu() {
        while (true) {
            System.out.println("\n======= ⚾ PinchHitter Recommender ⚾ =======");
            System.out.println("1. 타자 등록  2. 투수 등록  3. 매치업 등록  4. 추천 시작  0. 종료");
            System.out.print("➤ 메뉴 선택: ");
            String input = sc.next();
            if (Pattern.matches("^[0-9]$+", input)) return Integer.parseInt(input);
            System.out.println("[오류] 숫자만 입력하세요.");
        }
    }

    public String inputKoreanName(String msg) {
        while (true) {
            System.out.print("➤ " + msg + " (한글): ");
            String name = sc.next();
            if (Pattern.matches("^[가-힣]+$", name)) return name;
            System.out.println("[오류] 한글 이름만 가능합니다.");
        }
    }

    public String inputHand(String msg) {
        while (true) {
            System.out.print("➤ " + msg + " (L/R): ");
            String hand = sc.next().toUpperCase();
            if (hand.equals("L") || hand.equals("R")) return hand;
            System.out.println("[오류] L 또는 R만 입력하세요.");
        }
    }

    public double inputDouble(String msg) {
        while (true) {
            System.out.print("➤ " + msg + ": ");
            String input = sc.next();
            try { return Double.parseDouble(input); } 
            catch (NumberFormatException e) { System.out.println("[오류] 숫자(실수)만 가능합니다."); }
        }
    }

    public int inputInt(String msg) {
        while (true) {
            System.out.print("➤ " + msg + ": ");
            String input = sc.next();
            if (Pattern.matches("^[0-9]+$", input)) return Integer.parseInt(input);
            System.out.println("[오류] 숫자(정수)만 가능합니다.");
        }
    }

    public int inputBaseState() {
        while (true) {
            System.out.println("\n[주자] 0:없음 1:1루 2:2루 3:3루 4:12루 5:13루 6:23루 7:만루");
            int state = inputInt("상황 번호 입력");
            if (state >= 0 && state <= 7) return state;
            System.out.println("[오류] 0~7 사이만 가능합니다.");
        }
    }
}