// MatchUp.java
package com.baseball.pinchhitter.model.vo;
public class MatchUp {
    private String bName; private String pName; private double matchAvg;
    public MatchUp(String bName, String pName, double avg) {
        this.bName = bName; this.pName = pName; this.matchAvg = avg;
    }
    public String getBName() { return bName; }
    public String getPName() { return pName; }
    public double getMatchAvg() { return matchAvg; }
}