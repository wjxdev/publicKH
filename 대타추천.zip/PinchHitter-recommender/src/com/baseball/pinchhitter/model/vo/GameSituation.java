// GameSituation.java
package com.baseball.pinchhitter.model.vo;

public class GameSituation {
    private int outCount;
    private int baseState;
    public GameSituation(int outCount, int baseState) { this.outCount = outCount; this.baseState = baseState; }
    public int getBaseState() { return baseState; }
}