package com.baseball.pinchhitter.model.vo;

public class Batter {
    private String name;
    private String hand;    
    private double contact; 
    private double power;   
    private double clutch;  
    private double avg;     

    public Batter() {}
    public Batter(String name, String hand, double contact, double power, double clutch, double avg) {
        this.name = name; this.hand = hand; this.contact = contact;
        this.power = power; this.clutch = clutch; this.avg = avg;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getHand() { return hand; }
    public void setHand(String hand) { this.hand = hand; }
    public double getContact() { return contact; }
    public void setContact(double contact) { this.contact = contact; }
    public double getPower() { return power; }
    public void setPower(double power) { this.power = power; }
    public double getClutch() { return clutch; }
    public void setClutch(double clutch) { this.clutch = clutch; }
    public double getAvg() { return avg; }
    public void setAvg(double avg) { this.avg = avg; }

    @Override
    public String toString() {
        return String.format("[%s] %-5s | 타율: %.3f | 컨택: %.1f | 파워: %.1f | 클러치: %.1f", 
                             hand, name, avg, contact, power, clutch);
    }
}