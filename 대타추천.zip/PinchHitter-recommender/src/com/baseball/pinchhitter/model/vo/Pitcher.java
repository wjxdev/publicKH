package com.baseball.pinchhitter.model.vo;

public class Pitcher {
    private String name;
    private String hand;   
    private double era;    
    private double power;  

    // 생성자
    public Pitcher(String name, String hand, double era, double power) {
        this.name = name;
        this.hand = hand;
        this.era = era;
        this.power = power;
    }

    // Getter들
    public String getName() { return name; }
    public String getHand() { return hand; }
    public double getEra() { return era; }
    public double getPower() { return power; }
} 