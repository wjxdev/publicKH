package com.baseball.pinchhitter.run;
import com.baseball.pinchhitter.controller.PinchHitterController;

public class Run {
    public static void main(String[] args) {
        new PinchHitterController().start();
    }
}