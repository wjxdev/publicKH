package com.baseball.pinchhitter.service;

import com.baseball.pinchhitter.model.vo.*;
import java.util.ArrayList;
import java.util.List;

public class PinchHitterService {
    private ArrayList<Batter> batters = new ArrayList<>();
    private ArrayList<Pitcher> pitchers = new ArrayList<>();
    private ArrayList<MatchUp> matchUps = new ArrayList<>();

    public void addBatter(Batter b) { batters.add(b); }
    public void addPitcher(Pitcher p) { pitchers.add(p); }
    public void addMatchUp(MatchUp m) { matchUps.add(m); }
    
    public ArrayList<Batter> getBatters() { return batters; }
    public ArrayList<Pitcher> getPitchers() { return pitchers; }

    // lineup 리스트에 없는 선수(벤치)만 골라서 추천
    public Batter recommend(int pIdx, int baseState, List<String> lineup) {
        if (batters.isEmpty() || pitchers.isEmpty()) return null;

        Pitcher p = pitchers.get(pIdx);
        Batter best = null;
        double maxScore = -1.0;

        for (Batter b : batters) {
            // [검증] 선발 명단(lineup)에 포함된 이름이면 계산 제외
            boolean isStarting = false;
            for(String sName : lineup) {
                if(sName.trim().equals(b.getName().trim())) {
                    isStarting = true;
                    break;
                }
            }
            if(isStarting) continue; 

            // 점수 계산 로직
            double score = (b.getContact() * 0.4) + (b.getPower() * 0.3) + (b.getClutch() * 0.3);
            if (p.getPower() >= 80) score += (b.getContact() * 0.15);
            else if (p.getPower() <= 50) score += (b.getPower() * 0.15);
            if (baseState >= 2) score += (b.getClutch() * 0.2);
            if (!b.getHand().equals(p.getHand())) score += 10.0;
            
            for (MatchUp m : matchUps) {
                if (m.getBName().equals(b.getName()) && m.getPName().equals(p.getName())) {
                    score += (m.getMatchAvg() * 50); 
                }
            }

            if (score > maxScore) {
                maxScore = score;
                best = b;
            }
        }
        return best;
    }
}